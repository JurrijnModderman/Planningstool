<?php
$servername = "localhost";
$username = "root";
$password = "mysql";
$myDB = "planningstool";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$myDB", 
        $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::
      ERRMODE_EXCEPTION);
  //echo "Connected succcesfully";
    }
    catch(PDOException $e)
    {
    echo "Connection failed: "  . $e->getMessage();
    }

    $sql = 'SELECT * FROM games';
    $query = $conn->prepare($sql);
    $query->execute();

    $geheel = $query->fetchAll();
    //var_dump($result);




?> 
<!DOCTYPE html>
<html>
<head>
	<title>Planningstool</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
</head>
<body>
  <?php echo file_get_contents('navbar.php'); ?>

<div class="grid-container">
  <div class="rij-1 flexer">
    <div class="grid-item item1"><img src="7_wonders.jpg">
    <td><a href="plannen.php?id=2<?php echo $deel['id'] ?>">7 wonders</a></td></div>
    <div class="grid-item item2"><img src="10min_kraak.jpg">
    <td><a href="plannen.php?id=9<?php echo $deel['id'] ?>">10 min kraak</a></td></div>
    <div class="grid-item item3"><img src="camel_up.png">
    <td><a href="plannen.php?id=3<?php echo $deel['id'] ?>">Camel up</a></td></div>
    <div class="grid-item item4"><img src="city_of_horror.jpg">
    <td><a href="plannen.php?id=12<?php echo $deel['id'] ?>">City of horror</a></td></div>
    <div class="grid-item item5"><img src="climbers.jpg">
    <td><a href="plannen.php?id=21<?php echo $deel['id'] ?>">Climbers</a></td></div>
  </div>
<div class="rij-2 flexer">
    <div class="grid-item item6"><img src="codenames_pictures.jpg">
    <td><a href="plannen.php?id=5<?php echo $deel['id'] ?>">Codenames pictures</a></td></div>
    <div class="grid-item item6"><img src="concept.jpg">
    <td><a href="plannen.php?id=8<?php echo $deel['id'] ?>">Concept</a></td></div>
    <div class="grid-item item7"><img src="counterfeiters.jpg">
    <td><a href="plannen.php?id=1<?php echo $deel['id'] ?>">Counterfeiters</a></td></div>
    <div class="grid-item item8"><img src="dale_of_merchants.png">
    <td><a href="plannen.php?id=6<?php echo $deel['id'] ?>">Dale of merchants</a></td></div>
    <div class="grid-item item9"><img src="dixit.jpg">
    <td><a href="plannen.php?id=7<?php echo $deel['id'] ?>">Dixit</a></td></div>
  </div>
<div class="rij-3 flexer">
    <div class="grid-item item10"><img src="downforce.jpg">
    <td><a href="plannen.php?id=11<?php echo $deel['id'] ?>">Downforce</a></td></div>
    <div class="grid-item item11"><img src="dragon_flagon.png">
    <td><a href="plannen.php?id=23<?php echo $deel['id'] ?>">Dragon flagon</a></td></div>
    <div class="grid-item item12"><img src="fantasy_realms.jpg">
    <td><a href="plannen.php?id=13<?php echo $deel['id'] ?>">Fantasy realms</a></td></div>
    <div class="grid-item item13"><img src="ghost_fightin_treasure_hunters.jpg">
    <td><a href="plannen.php?id=10<?php echo $deel['id'] ?>">Ghost fightin treasure hunters</a></td></div>
    <div class="grid-item item14"><img src="gizmos.jpg">
    <td><a href="plannen.php?id=22<?php echo $deel['id'] ?>">Gizmos</a></td></div>
  </div>
  <div class="rij-4 flexer">
    <div class="grid-item item15"><img src="john.png">
    <td><a href="plannen.php?id=25<?php echo $deel['id'] ?>">John</a></td></div>
    <div class="grid-item item16"><img src="keep_talking_and_nobody_explodes.jpg">
    <td><a href="plannen.php?id=19<?php echo $deel['id'] ?>">Keep talking and nobody explodes</a></td></div>
    <div class="grid-item item17"><img src="lemming_mafias.jpg">
    <td><a href="plannen.php?id=15<?php echo $deel['id'] ?>">Lemming mafias</a></td></div>
    <div class="grid-item item18"><img src="micropolis.png">
    <td><a href="plannen.php?id=16<?php echo $deel['id'] ?>">Micropolis</a></td></div>
    <div class="grid-item item19"><img src="mysterium.png">
    <td><a href="plannen.php?id=17<?php echo $deel['id'] ?>">Mysterium</a></td></div>
  </div>
  <div class="rij-5 flexer">
    <div class="grid-item item20"><img src="notalone.png">
    <td><a href="plannen.php?id=20<?php echo $deel['id'] ?>">Notalone</a></td></div>
    <div class="grid-item item21"><img src="pandemic.png">
    <td><a href="plannen.php?id=24<?php echo $deel['id'] ?>">Pandemic</a></td></div>
    <div class="grid-item item22"><img src="roborally.jpg">
    <td><a href="plannen.php?id=4<?php echo $deel['id'] ?>">Roborally</a></td></div>
    <div class="grid-item item23"><img src="spyfall.jpg">
    <td><a href="plannen.php?id=18<?php echo $deel['id'] ?>">Spyfall</a></td></div>
    <div class="grid-item item24"><img src="the_estates.jpg">
    <td><a href="plannen.php?id=14<?php echo $deel['id'] ?>">The estates</a></td></div>
  

</div>
<div class="footer">© Jurrijn Modderman 4-6-2019</div>
</body>
</html>