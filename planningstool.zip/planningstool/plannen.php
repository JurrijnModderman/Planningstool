<!DOCTYPE html>
<html>
<head>
	<title>Plannen</title>
	<link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
</head>
<body>
<?php echo file_get_contents('navbar.php'); ?>
  
<?php
$servername = "localhost";
$username = "root";
$password = "mysql";
$myDB = "planningstool";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$myDB", 
        $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::
      ERRMODE_EXCEPTION);
  //echo "Connected succcesfully";
    }
    catch(PDOException $e)
    {
    echo "Connection failed: "  . $e->getMessage();
    }
    $id = $_GET["id"];
    $sql = 'SELECT * FROM games WHERE id = ?';
    $query = $conn->prepare($sql);
    $query->bindParam(1, $id);
    $query->execute();

    $geheel = $query->fetchAll();
    //var_dump($result);




?>
  <h1>Formulier</h1>
  <form action="insert.php" method="POST">
    <label>Welk spel wil je spelen?</label><select type="text" name="name">
    <option value="7 Wonders">7 Wonders</option>
    <option value="10 Min Kraak">10 Min Kraak</option>
    <option value="Camel Up">Camel Up</option>
    <option value="City Of Horror">City Of Horror</option>
    <option value="Climbers">Climbers</option>
    <option value="Codenames Pictures">Codenames Pictures</option>
    <option value="Concept">Concept</option>
    <option value="Counterfeiters">Counterfeiters</option>
    <option value="Dale Of Merchants">Dale Of Merchants</option>
    <option value="Dixit">Dixit</option>
    <option value="Downforce">Downforce</option>
    <option value="Dragon Flagon">Dragon Flagon</option>
    <option value="Fantasy Realms">Fantasy Realms</option>
    <option value="Ghost Fightin Treasure Hunters">Ghost Fightin Treasure Hunters</option>
    <option value="Gizmos">Gizmos</option>
    <option value="John">John</option>
    <option value="Keep Talking and Nobody Explodes">Keep Talking And Nobody Explodes</option>
    <option value="Lemming Mafias">Lemming Mafias</option>
    <option value="Micropolis">Micropolis</option>
    <option value="Mysterium">Mysterium</option>
    <option value="Notalone">Notalone</option>
    <option value="Pandemic">Pandemic</option>
    <option value="Roborally">Roborally</option>
    <option value="Spyfall">Spyfall</option>
    <option value="The Estates">The Estates</option>
    </select><br>

    <label>Met hoeveel spelers kan je dit spel minimaal spelen?</label>
    <input type="text" name="min_players"><br></input>
    <label>Met hoeveel spelers kan je dit spel maximaal spelen?</label>
    <input type="text" name="max_players"><br></input>
    <label>Hoelang duurt het spel?</label>
    <input type="text" name="play_minutes"><br></input>
    <label>Hoelang duurt het uitleggen?</label>
    <input type="text" name="explain_minutes"><br></input>

  <p><button type="submit" class="btn btn-primary">Toevoegen</button></p>


    
 </form>
    <tr>
        <th>name</th>
        <th>image</th>
        <th>description</th>
        <th>expansions</th>
        <th>skills</th>
        <th>url</th>
        <th>youtube</th>
        <th>min_players</th>
        <th>max_players</th>
        <th>play_minutes</th>
        <th>explain_minutes</th>
    </tr>
 <?php
  foreach ($geheel as $deel) {
 ?>   
    <tr>
        <td><?php echo $deel['name'] ?></td>
        <td><?php echo $deel['image'] ?></td>
        <td><?php echo $deel['description'] ?></td>
        <td><?php echo $deel['expansions'] ?></td>
        <td><?php echo $deel['skills'] ?></td>
        <td><?php echo $deel['url'] ?></td>
        <td><?php echo $deel['youtube'] ?></td>
        <td><?php echo $deel['min_players'] ?></td>
        <td><?php echo $deel['max_players'] ?></td>
        <td><?php echo $deel['play_minutes'] ?></td>
        <td><?php echo $deel['explain_minutes'] ?></td>
    </tr>
<?php
    }
?>        

</table>

</body>
</html>