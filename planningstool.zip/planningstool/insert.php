<?php
$servername = "localhost";
$username = "root";
$password = "mysql";
$myDB = "planningstool";




try {
	$conn = new PDO("mysql:host=$servername;dbname=$myDB", 
        $username, $password);
	// set the PDO error mode to exception
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::
	    ERRMODE_EXCEPTION);
	//echo "Connected succcesfully";
    }
    catch(PDOException $e)
    {
    echo "Connection failed: "	. $e->getMessage();
    }



    $name = $_POST['name'];
    $min_players = $_POST['min_players'];
    $max_players = $_POST['max_players'];
    $play_minutes = $_POST['play_minutes'];
    $explain_minutes = $_POST['explain_minutes'];

 $stmt = $conn->prepare("INSERT INTO games (name, min_players, max_players, play_minutes, explain_minutes)
        VALUES (:name, :min_players, :max_players, :play_minutes, :explain_minutes)");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':min_players', $min_players);
    $stmt->bindParam(':max_players', $max_players);
    $stmt->bindParam(':play_minutes', $play_minutes);
    $stmt->bindParam(':explain_minutes', $explain_minutes);

   

    $stmt->execute();

    header('Location: speltest.php');

    $conn = null;

?>