<nav class="navbar navbar-expand-lg navbar-light bg-light">
  

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Overzicht spellen <span class="sr-only">(current)</span></a>
      </li>
      
      </li>
       <li class="nav-item">
        <a class="nav-link" href="speltest.php">Info spellen</a>
      </li>
      
    </ul>
  </div>
</nav>